
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/pages/mailbox.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div style="height:7rem;" class="container"></div>
<?php if(auth()->guard()->check()): ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-4">
      <div class="user-wrapper">
        <ul class="users">
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="user" id="<?php echo e($user->id); ?>">
            <?php if($user->unread): ?>
            <span class="pending"><?php echo e($user->unread); ?></span>
            <?php endif; ?>
            <div class="media">
              <div class="media-left">
                <img src="<?php echo e(asset('/'.$user->avatar)); ?>" alt="" class="media-object">
              </div>
              <div class="media-body">
                <p class="name"><?php echo e($user->name); ?></p>
                <p class="email"><?php echo e($user->email); ?></p>
              </div>
            </div>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
    <div class="col-md-8" id="messages">


    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  var receiver_id='';
  var my_id ="<?php echo e(Auth::id()); ?>";
  $(document).ready(function(){
$.ajaxSetup({
headers: {
'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
});
// Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;
    
    var pusher = new Pusher('127836e025f2ddef8d35', {
    cluster: 'eu',
    forceTLS:true
    });
    
    var channel = pusher.subscribe('TutorsWebsite');
    channel.bind('my-event', function(data) {

      if(my_id == data.from){
        $('#'+data.to).click();
        $("#chatInput").click();
      }else if(my_id == data.to)
        {
        if(receiver_id == data.from)
        {
          //if receiver is selected relad selected user
          $('#' + data.from).click();
        }else
          {
          //if receiver is not selected, add notification to that user
          var pending = parseInt($('#' + data.from).find('.pending').html());
          
          if(pending)
          {
            $('#' + data.from).find('.pending').html(pending + 1);
          }
          else
          {
            $('#' + data.from).append('<span class="pending">1</span>');
          }
        }
      }
//    alert(JSON.stringify(data));
    });
    //end of pusher logs
    $('.user').click(function(){

      $('.user').removeClass('active');
      $(this).addClass('active');
      $(this).find('.pending').remove();
      receiver_id = $(this).attr('id') ;   
      $.ajax({
        type:"get",
        url:("message/"+receiver_id),
        data:"",
        cashe:false,
        success: function(data){
          $('#messages').html(data);
          $('.messages-wrapper').scrollTop($('.messages-wrapper')[0].scrollHeight);
          }
        
      });

      });
      $(document).on('keyup','.input-text input',function (e){
        var message = $(this).val();
        //work on press enter and massage not null and receiver choosed
        if(e.keyCode == 13 && message != '' && receiver_id != ''){
        // empty text box after sending massage
        $(this).val('');
        var datastr = "receiver_id=" + receiver_id +"&message="+message;
        //store data in db
        $.ajax({
          type: "post",
          url: "sendmessage",
          data: datastr,
          cashe:false,
          succes:function(data){
          },
          error:function(jqXHR,status,err){

          },complete:function(){
            $('.messages-wrapper').scrollTop($('.messages-wrapper')[0].scrollHeight);
            }
        });
        }
      });


  });
</script>


<?php endif; ?>
<?php if (! (Auth::check())): ?>
<h1>NIE JESTEŚ ZALOGOWANY</h1>
<?php endif; ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/messages/chat.blade.php ENDPATH**/ ?>