

<?php $__env->startSection('content'); ?>
<h1>logowanie</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/pages/signIn.blade.php ENDPATH**/ ?>