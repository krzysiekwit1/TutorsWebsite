<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="height:5rem;" class="container"></div>
 <h1 style='text-align:center;'> ODEBRANE</h1>

<div class="container">
<?php $__currentLoopData = $messagesFromYou; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messageFromYou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="border-bottom:1px solid 	#B8B8B8;margin-top:5px;margin-bottom:5px;" class="row">
 <div  class="col-md-4 col-xl-4">
<h2>Tytuł:<?php echo e($messageFromYou->title); ?></h2>
</div>
 <div  class="col-md-4 col-xl-4">
<h2><?php echo e($messageFromYou->name); ?></h2>
</div>
 <div  class="col-md-4 col-xl-4">
  <a style="font-size:17px;margin-bottom:5px;" href="/mailbox/show/<?php echo e($messageToYou->id); ?> class="btn btn-info">Otwórz</a>
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div style="margin-top:50px;" class="container">

</div>
<div class="container">
 <h1 style='text-align:center;'> WYSŁANE</h1>
</div>
<div class="container">
<?php $__currentLoopData = $messagesToYou; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messageToYou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="border-bottom:1px solid 	#B8B8B8;margin-top:5px;margin-bottom:5px;" class="row">
 <div  class="col-md-4 col-xl-4">
<h2>Tytuł:<?php echo e($messageToYou->title); ?></h2>
</div>
 <div  class="col-md-4 col-xl-4">
<h2><?php echo e($messageToYou->name); ?></h2>
</div>
 <div  class="col-md-4 col-xl-4">
  <a style="font-size:17px;margin-bottom:5px;" href="/mailbox/show/<?php echo e($messageToYou->id); ?> class="btn btn-info">Otwórz</a>
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/pages/mailbox.blade.php ENDPATH**/ ?>