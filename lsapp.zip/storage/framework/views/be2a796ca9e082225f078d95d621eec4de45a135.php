

<?php $__env->startSection('content'); ?>
<h1>rejestrowanie</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/pages/signUp.blade.php ENDPATH**/ ?>