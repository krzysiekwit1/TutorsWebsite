<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="height:5rem;" class="container"></div>
    <?php echo $__env->make('errorMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php if(auth()->guard()->check()): ?>

<?php echo Form::open(['action'=>'MessagesController@store','method'=>'POST','style'=>'width:100%;heiht:50%;']); ?>


<div class="container">
 <div class="row">
  <?php echo e(Form::hidden('user_id_2', $user_id_2)); ?>

 <?php echo e(Form::label('Wyslij do','Wyślij do')); ?>

<?php echo e(Form::text('Wyslij do',$name,['class'=>'form-control','style'=>'font-size: 18px;','readonly'])); ?>

 </div>
 <div class="row">
  <?php echo e(Form::label('title','Tytuł')); ?>

<?php echo e(Form::text('title','',['class'=>'form-control','placeholder'=>'Tytuł','style'=>'font-size: 18px;'])); ?>

 </div>
 <div class="row">
  <?php echo e(Form::label('text','Treść wiadomości')); ?>

<?php echo e(Form::textarea('text','',['class'=>'form-control','placeholder'=>'Treść Wiadomości','style'=>'font-size: 18px;'])); ?> </div>
 <div class="row">
<?php echo e(FORM::submit('Submit',['class'=>'btn btn-primary','style'=>'font-size: 18px;'])); ?>


 </div>
</div>



<?php echo Form::close(); ?>

<?php endif; ?>
<?php if (! (Auth::check())): ?>
<h1>NIE JESTEŚ ZALOGOWANY</h1>
<?php endif; ?><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/messages/create.blade.php ENDPATH**/ ?>