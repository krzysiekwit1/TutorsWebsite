<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="height:7rem;"class="container"></div>

<div class="container">
<div class="row">
<div class="col-md-4 col-xl-4">
<?php echo e(date('Y')); ?>

</div>
<div class="col-md-4 col-xl-4">
<?php echo e(date('m')); ?>

</div>
<div class="col-md-4 col-xl-4">

</div>
</div>
</div>
<?php echo e($numberOfDays); ?>

<div class="container">

<div class="row" style="margin-top:20px;">
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
    <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
    <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
</div>

<div class="row" style="margin-top:20px;">
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
    <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>

  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>

</div>
<div class="row" style="margin-top:20px;">
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>

  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>

</div>
  <div class="row" style="margin-top:20px;">
    <div class="col-lg-2 col-md-2">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title"></h5>
          <h6 class="card-subtitle mb-2 text-muted"></h6>
          <p class="card-text"></p>
          <a href="#" class="card-link"></a>
          <a href="#" class="card-link"></a>
        </div>
      </div>
    </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
    </div>
  </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>

  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>
          <h6 class="card-subtitle mb-2 text-muted"></h6>
          <p class="card-text"></p>
          <a href="#" class="card-link"></a>
          <a href="#" class="card-link"></a>
        </div>
      </div>
  </div>
  </div>
<div class="row" style="margin-top:20px;">

  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
<div class="col-lg-2 col-md-2">
  <div class="card">
    <div class="card-body">
      <h5 class="card-title"></h5>
      <h6 class="card-subtitle mb-2 text-muted"></h6>
      <p class="card-text"></p>
      <a href="#" class="card-link"></a>
      <a href="#" class="card-link"></a>
    </div>
  </div>
</div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <div class="col-lg-2 col-md-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"></h5>
        <h6 class="card-subtitle mb-2 text-muted"></h6>
        <p class="card-text"></p>
        <a href="#" class="card-link"></a>
        <a href="#" class="card-link"></a>
      </div>
    </div>
  </div>
  <?php if($numberOfDays>28): ?>

    <div class="col-lg-2 col-md-2">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title"></h5>
          <h6 class="card-subtitle mb-2 text-muted"></h6>
          <p class="card-text"></p>
          <a href="#" class="card-link"></a>
          <a href="#" class="card-link"></a>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if($numberOfDays>29): ?>

    <div class="col-lg-2 col-md-2">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title"></h5>
          <h6 class="card-subtitle mb-2 text-muted"></h6>
          <p class="card-text"></p>
          <a href="#" class="card-link"></a>
          <a href="#" class="card-link"></a>
        </div>
      </div>
    </div>
  <?php endif; ?>

</div>
  <?php if($numberOfDays>30): ?>

    <div class="row" style="margin-top:20px;">
      <div class="col-lg-2 col-md-2">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title"></h5>
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p class="card-text"></p>
            <a href="#" class="card-link"></a>
            <a href="#" class="card-link"></a>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>



</div><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/calendar/show.blade.php ENDPATH**/ ?>