<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="height:5rem;" class="container">
 <?php if(auth()->guard()->check()): ?>

</div>

<div style="border-bottom:1px solid black;border-top:1px solid black;" class="container">
<h2><?php echo e($message[0]->title); ?></h2>
<a class="btn btn-primary float-right"style="font-size:10px;width:100px;margin-left:5px;" href="#" role="button">Dodaj Zajęcia</a>
 <h3 style="text-align:right;">

   <?php if(Auth::user()->id==$message[0]->user_id_1): ?>
    do:<?php echo e($user[0]->name); ?>

   <?php else: ?>
    od:<?php echo e($user[0]->name); ?>

   <?php endif; ?>
 
 </h3>
<div class="container">
 <div class="row">
  <div style="margin-top:10px;margin-bottom:10px;height:100px;background-color:	#E8E8E8;"class="col-md-12 col-xl-12">
   <?php echo e($message[0]->text); ?>

  </div>
 </div>
</div>
</div>

<?php endif; ?><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/messages/show.blade.php ENDPATH**/ ?>