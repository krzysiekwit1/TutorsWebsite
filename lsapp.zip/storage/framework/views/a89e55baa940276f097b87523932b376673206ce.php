
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/pages/mailbox.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div style="height:7rem;" class="container"></div>
<?php if(auth()->guard()->check()): ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-4">
      <div class="user-wrapper">
        <ul class="users">
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="user" id="<?php echo e($user->id); ?>">
            <span class="pending">1</span>
            <div class="media">
              <div class="media-left">
                <img src="<?php echo e($user->avatar); ?>" alt="" class="media-object">
              </div>
              <div class="media-body">
                <p class="name"><?php echo e($user->name); ?></p>
                <p class="email"><?php echo e($user->email); ?></p>
              </div>
            </div>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
    <div class="col-md-8" id="messages">

    </div>
  </div>
</div>
</div>


<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  var receiver_id='';
  var my_id ="<?php echo e(Auth::id()); ?>";
  $(document).ready(function(){
    $('.user').click(function(){
      $('.user').removeClass('active');
      $(this).addClass('active');
      chuj =$('.user').attr('id');

      receiver_id = $(this).attr('id') ;   
      $.ajax({
        type:"get",
        url("message/"+receiver_id),
        data:"",
        cashe:false,
        succes: function(data){
          alert(data);
        }
        
      });
      });
  })
</script>


<?php endif; ?>
<?php if (! (Auth::check())): ?>
<h1>NIE JESTEŚ ZALOGOWANY</h1>
<?php endif; ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjektDyplomowy\lsapp\resources\views/messages/mailbox.blade.php ENDPATH**/ ?>