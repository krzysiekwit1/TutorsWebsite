@include ('layouts.mainlayout')
<div style="height:5rem;" class="container">
 @auth

</div>

<div style="border-bottom:1px solid black;border-top:1px solid black;" class="container">

</div>

@endauth